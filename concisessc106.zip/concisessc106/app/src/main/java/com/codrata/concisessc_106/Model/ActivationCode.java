package com.codrata.concisessc_106.Model;

public class ActivationCode {
    private String Pin;

    public ActivationCode() {
    }

    public ActivationCode(String pin) {
        Pin = pin;
    }

    public String getPin() {
        return Pin;
    }

    public void setPin(String pin) {
        Pin = pin;
    }

}
